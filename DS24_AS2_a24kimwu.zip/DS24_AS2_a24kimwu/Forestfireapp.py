from flask import Flask, request, jsonify
import threading
import pickle
import numpy as np

with open("model.pkl", "rb") as f:
    model = pickle.load(f)

app = Flask(__name__)

@app.route("/")
def home():
    return "Model Deployment with Flask is up and running!"

print("Flask script started!")

@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.get_json()
        features = np.array(data["features"]).reshape(1, -1)
        
        prediction = model.predict(features)
        response = {"prediction": float(prediction[0])}
    except Exception as e:
        response = {"error": str(e)}
    
    return jsonify(response)

print('Starting Flask app...')

def run_flask():
    app.run(debug=False, use_reloader=False, host="127.0.0.1", port=5001)

flask_thread = threading.Thread(target=run_flask)
flask_thread.start()